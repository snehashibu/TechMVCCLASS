<table border="1">
<tr>
<td>id</td>
<td>title</td>
<td>body</td>
<td>edit</td>
<td>delete</td>
</tr>
<?php $__currentLoopData = $share; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($value->id); ?></td>
<td><?php echo e($value->title); ?></td>
<td><?php echo e($value->body); ?></td>
<td><a href="<?php echo e(route('shares.edit',$value->id)); ?>">Edit</a></td>
<td>    
<form action="<?php echo e(route('shares.destroy',$value->id)); ?>" method="post">
<?php echo csrf_field(); ?>
<?php echo method_field('DELETE'); ?>
<button type="submit">Delete</button>
</form>


</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
