@extends('layout.app')
@section('content')
<h1>home</h1>
<P> haiiiiiiiiiii<p>
@endsection