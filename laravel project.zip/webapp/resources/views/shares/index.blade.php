<table border="1">
<tr>
<td>id</td>
<td>title</td>
<td>body</td>
<td>edit</td>
<td>delete</td>
</tr>
@foreach($share as $value)
<tr>
<td>{{$value->id}}</td>
<td>{{$value->title}}</td>
<td>{{$value->body}}</td>
<td><a href="{{route('shares.edit',$value->id)}}">Edit</a></td>
<td>    
<form action="{{route('shares.destroy',$value->id)}}" method="post">
@csrf
@method('DELETE')
<button type="submit">Delete</button>
</form>


</td>
</tr>
@endforeach

</table>
